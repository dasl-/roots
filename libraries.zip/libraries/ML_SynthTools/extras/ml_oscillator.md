<h1 align="center">Oscillator</h1>
<h3 align="center">Saw wave oscillator with PWM</h3>  

This module provides a saw-wave with a modulated pwm.
Little demo: https://youtu.be/8ipPJ8rEOQM 
Example project: https://github.com/marcel-licence/ml_synth_pwm_osc_example