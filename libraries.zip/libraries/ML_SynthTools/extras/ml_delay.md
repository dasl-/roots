<h1 align="center">Delay</h1>
<h3 align="center">A very simple delay</h3>  

This module provides a delay effect.
It supports two delay lines for a stereo delay.
The Delay_Init function needs a buffer and the length for a mono delay.
For stereo please use Delay_Init2 which needs two buffers.