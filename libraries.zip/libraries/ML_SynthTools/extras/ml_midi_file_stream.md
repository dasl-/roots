<h1 align="center">MIDI file stream player</h1>
<h3 align="center">Overview</h3>  

This module provides a midi file stream player.
It does require only a very small amount of RAM.
Only one track can be played (can play all 16 channels when using MIDI format 0)
Little demo: https://youtu.be/LaAImFWOt1M
