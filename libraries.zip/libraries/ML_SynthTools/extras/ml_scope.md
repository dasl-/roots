<h1 align="center">Scope</h1>
<h3 align="center">A little steady OLED Scope</h3>  

This little module is to drive a SSD1301 OLED scope.
You can put samples in it and it can push a picture to the I2C connected OLED.
The module does compute two channels and try to talk to two OLEDs (address: 0x3C, 0x3D)

More information is coming soon.

Planned updates:
- extract the SSD1306 specific code
- samples input -> normalized signal output