<h1 align="center">Arpeggio</h1>
<h3 align="center">A simple arpeggio module</h3>  

This module can be used to allow playing arpeggios.
It is in an experimental stage.
Some sequences are integrated and can be used.

Planned updates:
- allowing slides
- integration of accents
- support of pause