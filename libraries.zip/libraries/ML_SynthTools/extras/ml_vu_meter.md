<h1 align="center">VU Meter</h1>
<h3 align="center">VU Meter calculation</h3>  

This experimental module should help to calculate values for a VU meter.

More information coming soon