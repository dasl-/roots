# Defines

Possible definitions will be listed below.

<table>
    <tr>
        <td>MIDI_USB_ENABLED</td>
        <td>Using Adafruit TinUSB the device should be appear as a MIDI device when connected to a computer</td>
    </tr>
</table>