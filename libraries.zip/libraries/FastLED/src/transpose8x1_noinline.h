
#pragma once
void transpose8x1_noinline(unsigned char *A, unsigned char *B);
