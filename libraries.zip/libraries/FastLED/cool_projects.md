  * Advanced Color Gradient using online version of FastLED.
    * https://wokwi.com/projects/285170662915441160
  * LedMapper tool for irregular shapes
    * https://github.com/jasoncoon/led-mapper
